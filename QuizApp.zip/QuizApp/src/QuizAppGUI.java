import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;

public class QuizAppGUI extends JFrame {
    String[] questions = {
        "Which data type stores text in Java?",
        "What does 'OOP' stand for?",
        "Which is a loop structure in Java?",
        "Keyword to define a class in Java?",
        "Symbol for single-line comments in Java?",
        "Which company developed Java?"
    };

    String[][] options = {
        {"int", "String", "char", "float"},
        {"Object Oriented Programming", "Open Online Platform", "Output Order Program", "Optical Output Protocol"},
        {"if", "switch", "while", "catch"},
        {"define", "method", "class", "function"},
        {"/*", "//", "--", "##"},
        {"Microsoft", "Google", "Sun Microsystems", "Apple"}
    };

    int[] answers = {1, 0, 2, 2, 1, 2}; // Correct option indexes

    int current = 0;
    int score = 0;
    int timeLeft = 10;

    JLabel questionLabel = new JLabel();
    JRadioButton[] radioButtons = new JRadioButton[4];
    ButtonGroup bg = new ButtonGroup();
    JButton submitButton = new JButton("Submit");
    JLabel timerLabel = new JLabel("Time left: 10s");
    Timer timer;

    public QuizAppGUI() {
        setTitle("Quiz App");
        setSize(500, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(7, 1));

        questionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        add(questionLabel);

        for (int i = 0; i < 4; i++) {
            radioButtons[i] = new JRadioButton();
            bg.add(radioButtons[i]);
            add(radioButtons[i]);
        }

        add(timerLabel);
        add(submitButton);

        submitButton.addActionListener(e -> submitAnswer());

        showQuestion();
    }

    void showQuestion() {
        if (current >= questions.length) {
            showResult();
            return;
        }

        questionLabel.setText("Q" + (current + 1) + ": " + questions[current]);

        for (int i = 0; i < 4; i++) {
            radioButtons[i].setText(options[current][i]);
            radioButtons[i].setSelected(false);
        }

        timeLeft = 10;
        timerLabel.setText("Time left: 10s");

        if (timer != null) {
            timer.cancel();
        }

        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                timeLeft--;
                SwingUtilities.invokeLater(() -> timerLabel.setText("Time left: " + timeLeft + "s"));
                if (timeLeft == 0) {
                    timer.cancel();
                    SwingUtilities.invokeLater(() -> submitAnswer());
                }
            }
        }, 1000, 1000);
    }

    void submitAnswer() {
        timer.cancel();
        int selected = -1;
        for (int i = 0; i < 4; i++) {
            if (radioButtons[i].isSelected()) {
                selected = i;
                break;
            }
        }

        if (selected == answers[current]) {
            score++;
        }

        current++;
        showQuestion();
    }

    void showResult() {
        JOptionPane.showMessageDialog(this, "Quiz Over!\nYour Score: " + score + "/" + questions.length);
        System.exit(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            QuizAppGUI quiz = new QuizAppGUI();
            quiz.setVisible(true);
        });
    }
}
