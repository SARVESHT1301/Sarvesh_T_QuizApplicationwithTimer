import java.util.*;
public class QuizApplication {
	static Scanner sc=new Scanner(System.in);
	static int score = 0;
	static int questionIndex = 0;
	
	static class Question {
		String questionText;
		String[] options;
		int correctOption;
		
		Question(String questionText, String[] options, int correctOption) {
			this.questionText = questionText;
			this.options = options;
			this.correctOption = correctOption;
		}
	}
	
	static List<Question> questionList = new ArrayList<>();
	
	public static void main(String[] args) {
		questionList.add(new Question("Which data type is used to create a variable that stores text in Java?", new String[]{"int", "String", "char", "float"}, 2));
        questionList.add(new Question("What does 'OOP' stand for?", new String[]{"Object Oriented Programming", "Open Online Platform", "Ordered Output Process", "Optical Output Protocol"}, 1));
        questionList.add(new Question("Which of these is a loop structure in Java?", new String[]{"if", "switch", "while", "catch"}, 3));
        questionList.add(new Question("Which keyword is used to define a class in Java?", new String[]{"define", "method", "class", "function"}, 3));
        questionList.add(new Question("Which symbol is used to add comments in a single line in Java?", new String[]{"/*", "//", "--", "##"}, 2));
        questionList.add(new Question("Which company originally developed Java?", new String[]{"Microsoft", "Google", "Sun Microsystems", "Apple"}, 3));
		
		for(Question q : questionList) {
			questionIndex++;
			askQuestion(q);
		}
		showResult();

	}
	
	public static void askQuestion(Question q) 
	{
		System.out.println("\nQuestion "+ questionIndex + ": " + q.questionText);
		for(int i=0;i<q.options.length;i++) {
			System.out.println((i+1) + ". " + q.options[i]);
		}
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			public void run() {
				System.out.println("\nTime's Up !  Moving to next Question.");
				synchronized (sc) {
					sc.notify();
					
				}
			}
		};
		timer.schedule(task,  10000);;
		
		int userAnswer = -1;
		try {
			synchronized(sc) {
				if(sc.hasNextInt() ) {
					userAnswer = sc.nextInt();
				}else {
					sc.wait(10000);
					
				}
			}
		} catch(Exception e) {
			System.out.println("Error reading input.");
		}
		timer.cancel();
		
		if(userAnswer == q.correctOption ) {
			System.out.println("Correct !");
			score++;
		}else if(userAnswer == -1) {
			System.out.println("No answer Provided.");
		}else {
			System.out.println("Incorrect Answer.\nCorrect Answer is : " + q.correctOption + ". " + q.options[q.correctOption - 1] );
			
		}
	}
	public static void showResult() {
		System.out.println("\nQuiz Finished!");
		System.out.println("Your Score : " + score + "/" + questionList.size());
		System.out.println("Thanks for Playing !");
		
	}

}
